#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>

// ================= WIFI =================
const char* ssid = "photon";
const char* password = "particle";

// ================= MQTT =================
const char* mqtt_server = "34.210.232.255";
const int mqtt_port = 8883;

// 🔐 credentials
const char* mqtt_user = "student";
const char* mqtt_pass = "egr3x4";

// ================= TOPICS =================
const char* topic_hmi = "EGR314/TEAM306/HMI_TO_NODE";
const char* topic_motor = "EGR314/TEAM306/NODE_TO_MOTOR";

// ================= IDS =================
const char MY_ID = 'A';
const char BROADCAST = 'X';

// ================= CLIENT =================
WiFiClientSecure espClient;
PubSubClient client(espClient);

// ================= UART (TEammate link) =================
HardwareSerial TeamSerial(2);

// RX / TX pins (change if needed)
#define RXD2 16
#define TXD2 17

// ================= MESSAGE BUFFER =================
String pendingMsg = "";
unsigned long msgTime = 0;
bool msgPending = false;

const unsigned long DELAY_MS = 5000;

// ================= BUILD MESSAGE =================
String buildMessage(char from, char to, String data) {
  return "AZ" + String(from) + String(to) + data + "YB";
}

// ================= MQTT SEND =================
void sendToMotor(String cmd) {
  String packet = buildMessage(MY_ID, 'M', cmd);

  Serial.println("➡ Sending to Motor: " + packet);

  client.publish(topic_motor, packet.c_str());
}

// ================= HMI HANDLER =================
void handleHMI(String msg) {

  Serial.println("HMI COMMAND: " + msg);

  if (msg == "MOTOR_ON") sendToMotor("START");
  else if (msg == "MOTOR_OFF") sendToMotor("STOP");
  else if (msg == "SPEED_UP") sendToMotor("SPEED+");
  else if (msg == "SPEED_DOWN") sendToMotor("SPEED-");
  else Serial.println("Unknown HMI command");
}

// ================= MQTT CALLBACK =================
void callback(char* topic, byte* payload, unsigned int length) {

  String msg = "";

  for (int i = 0; i < length; i++) {
    msg += (char)payload[i];
  }

  Serial.println("\nMQTT RX: " + msg);

  if (String(topic) == topic_hmi) {
    handleHMI(msg);
  }

  // optional protocol parsing
  if (msg.startsWith("AZ") && msg.endsWith("YB")) {

    char from = msg[2];
    char to = msg[3];
    String content = msg.substring(4, msg.length() - 2);

    if (to == MY_ID || to == BROADCAST) {
      Serial.println("TEAM MSG: " + content);
    }
  }
}

// ================= WIFI =================
void setup_wifi() {

  Serial.print("Connecting WiFi");

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");
}

// ================= MQTT RECONNECT =================
void reconnect() {

  while (!client.connected()) {

    Serial.print("Connecting MQTT...");

    if (client.connect("ESP32_NODE_A", mqtt_user, mqtt_pass)) {
      Serial.println("connected");
      client.subscribe(topic_hmi);
    } else {
      Serial.print("FAILED rc=");
      Serial.println(client.state());
      delay(2000);
    }
  }
}

// ================= UART INPUT =================
void checkUART() {

  while (TeamSerial.available()) {

    String msg = TeamSerial.readStringUntil('\n');
    msg.trim();

    if (msg.length() == 0) return;

    Serial.println("📥 UART RX: " + msg);

    // 1. publish immediately to MQTT
    client.publish(topic_motor, msg.c_str());

    // 2. store for delayed forwarding
    pendingMsg = msg;
    msgTime = millis();
    msgPending = true;
  }
}

// ================= DELAYED FORWARD =================
void checkForward() {

  if (msgPending && (millis() - msgTime >= DELAY_MS)) {

    Serial.println("➡ UART FORWARD: " + pendingMsg);

    TeamSerial.println(pendingMsg);

    msgPending = false;
    pendingMsg = "";
  }
}

// ================= SETUP =================
void setup() {

  Serial.begin(115200);

  // UART link to teammate
  TeamSerial.begin(115200, SERIAL_8N1, RXD2, TXD2);

  setup_wifi();

  espClient.setInsecure();

  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(callback);
}

// ================= LOOP =================
void loop() {

  if (!client.connected()) {
    reconnect();
  }

  client.loop();

  checkUART();      // receive from teammate
  checkForward();   // send after 5 seconds
}